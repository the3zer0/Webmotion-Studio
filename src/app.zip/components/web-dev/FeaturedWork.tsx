'use client'

const projects = [
  {
    title: 'Modern Agency Website',
    category: 'Business Website',
  },
  {
    title: 'Creative Portfolio',
    category: 'Portfolio',
  },
  {
    title: 'SaaS Landing Page',
    category: 'Landing Page',
  },
]

export default function FeaturedWork() {
  return (
    <section
      id="portfolio"
      className="py-32 px-6 bg-[#151515]"
    >
      <div className="max-w-7xl mx-auto">

        {/* Heading */}
        <div className="text-center mb-20">
          <p className="text-[#f7b801] uppercase tracking-[0.3em] text-sm mb-4">
            Featured Work
          </p>

          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Recent Projects
          </h2>

          <p className="text-zinc-400 max-w-2xl mx-auto text-lg">
            Websites built to impress visitors,
            strengthen brands, and increase conversions.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">

          {projects.map((project) => (
            <div
              key={project.title}
              className="
                group
                rounded-[2rem]
                overflow-hidden
                border
                border-white/10
                bg-white/[0.03]
                hover:border-[#ff6b35]/40
                transition-all
                duration-300
              "
            >

              {/* Browser Mockup */}
              <div>

                {/* Browser Header */}
                <div className="flex items-center gap-2 px-5 py-4 border-b border-white/10">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                </div>

                {/* Screenshot Placeholder */}
                <div
                  className="
                    h-[320px]
                    bg-gradient-to-br
                    from-white/[0.04]
                    to-white/[0.01]
                    flex
                    items-center
                    justify-center
                  "
                >
                  <div className="text-center">

                    <div
                      className="
                        w-20
                        h-20
                        rounded-3xl
                        bg-gradient-to-br
                        from-[#ff6b35]
                        to-[#f7b801]
                        mx-auto
                        mb-4
                      "
                    />

                    <p className="text-zinc-500 text-sm uppercase tracking-[0.2em]">
                      Add Screenshot
                    </p>

                  </div>
                </div>

              </div>

              {/* Content */}
              <div className="p-6">

                <p className="text-[#f7b801] text-sm uppercase tracking-[0.2em] mb-2">
                  {project.category}
                </p>

                <h3 className="text-2xl font-semibold text-white">
                  {project.title}
                </h3>

              </div>

            </div>
          ))}

        </div>

      </div>
    </section>
  )
}