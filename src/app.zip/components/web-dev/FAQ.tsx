'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const faqs = [
  {
    question: 'How long does a website take to build?',
    answer:
      "Most websites are completed within 2–4 weeks, depending on the project's complexity., content requirements, and revision rounds.",
  },
  {
    question: 'Do you design before development?',
    answer:
      'Yes, every project begins with a design phase to ensure the best user experience and visual direction',
  },
  {
    question: 'Will my website be mobile responsive?',
    answer:
      'Absolutely, all websites we build are fully responsive across desktop, tablet, and mobile devices.',
  },
  {
    question: 'Do you provide hosting support?',
    answer:
      'Yes, we can help with hosting setup, deployment, and ongoing website maintenance.',
  },
  {
    question: 'Can you redesign an existing website?',
    answer:
      'Yes, we can modernize and optimize your existing website for better performance and user experience.',
  },
  {
    question: 'Do you build custom features?',
    answer:
      'Yes, we develop custom functionality tailored to your specific business requirements.',
  },
]

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <section className="py-32 px-6 bg-[#111111]">
      <div className="max-w-4xl mx-auto">

        {/* Heading */}
        <div className="text-center mb-20">
          <p className="text-[#f7b801] uppercase tracking-[0.3em] text-sm mb-4">
            FAQ
          </p>

          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Frequently Asked Questions
          </h2>

          <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
            Common questions about our web design and development process.
          </p>
        </div>

        {/* FAQ Items */}
        <div className="space-y-5">

          {faqs.map((faq, index) => {
            const isOpen = openIndex === index

            return (
              <div
                key={faq.question}
                className="
                  rounded-3xl
                  border
                  border-white/10
                  bg-white/[0.03]
                  overflow-hidden
                "
              >
                <button
                  onClick={() =>
                    setOpenIndex(isOpen ? null : index)
                  }
                  className="
                    w-full
                    flex
                    items-center
                    justify-between
                    p-8
                    text-left
                  "
                >
                  <h3 className="text-white text-xl font-semibold">
                    {faq.question}
                  </h3>

                  <ChevronDown
                    size={24}
                    className={`
                      text-[#ff6b35]
                      transition-transform
                      duration-300
                      ${isOpen ? 'rotate-180' : ''}
                    `}
                  />
                </button>

                <div
                  className={`
                    grid
                    transition-all
                    duration-300
                    ${
                      isOpen
                        ? 'grid-rows-[1fr]'
                        : 'grid-rows-[0fr]'
                    }
                  `}
                >
                  <div className="overflow-hidden">
                    <p className="px-8 pb-8 text-zinc-400 leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              </div>
            )
          })}

        </div>

      </div>
    </section>
  )
}