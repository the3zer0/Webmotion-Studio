'use client'

import Link from 'next/link'

const stats = [
  {
    value: '30+',
    label: 'Websites Delivered',
  },
  {
    value: '12+',
    label: 'Industries Served',
  },
  {
    value: '99%',
    label: 'Client Satisfaction',
  },
  {
    value: '<3s',
    label: 'Average Load Time',
  },
]

export default function Hero() {
  return (
    <section className="relative min-h-screen overflow-hidden bg-[#111111]">
      {/* Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-[#ff6b35]/10 blur-[200px]" />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8 pt-40 pb-24">
        <div className="grid lg:grid-cols-2 gap-20 items-center">

          {/* Left */}
          <div>

            <p className="text-[#f7b801] uppercase tracking-[0.35em] text-sm mb-6">
              WEB DEVELOPMENT • UI/UX • DIGITAL EXPERIENCES
            </p>

            <h1 className="text-[4rem] md:text-[6rem] leading-[0.9] font-bold text-white">
              WE BUILD
              <br />

              <span className="bg-gradient-to-r from-[#ff6b35] to-[#f7b801] bg-clip-text text-transparent">
                WEBSITES
              </span>

              <br />
              THAT
              <br />
              CONVERT.
            </h1>

            <p className="mt-8 text-zinc-400 text-lg max-w-xl leading-relaxed">
              High-performance websites designed to build trust,
              generate leads, and turn visitors into customers.
            </p>

            <div className="flex flex-wrap gap-4 mt-10">

              <a
                href="#featured-work"
                className="
                  px-8
                  py-4
                  rounded-full
                  bg-gradient-to-r
                  from-[#ff6b35]
                  to-[#f7b801]
                  text-black
                  font-semibold
                  hover:scale-105
                  transition
                "
              >
                View Projects
              </a>

              <Link
                href="#contact"
                className="
                  px-8
                  py-4
                  rounded-full
                  border
                  border-white/15
                  text-white
                  hover:border-[#ff6b35]
                  transition
                "
              >
                Start Project
              </Link>

            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16">

              {stats.map((stat) => (
                <div key={stat.label}>
                  <h3 className="text-4xl font-bold text-[#ff6b35]">
                    {stat.value}
                  </h3>

                  <p className="text-zinc-500 mt-2 text-sm">
                    {stat.label}
                  </p>
                </div>
              ))}

            </div>

          </div>

          {/* Right */}
          <div className="relative">

            {/* Main Website Preview */}
            <div
              className="
                rounded-[2rem]
                border
                border-white/10
                bg-white/[0.03]
                backdrop-blur-xl
                overflow-hidden
              "
            >

              {/* Browser Header */}
              <div className="flex items-center gap-2 px-6 py-4 border-b border-white/10">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <div className="w-3 h-3 rounded-full bg-green-500" />
              </div>

              {/* Website Placeholder */}
              <div className="h-[500px] flex items-center justify-center bg-gradient-to-br from-white/[0.03] to-white/[0.01]">

                <div className="text-center">

                  <div
                    className="
                      w-24
                      h-24
                      rounded-3xl
                      bg-gradient-to-br
                      from-[#ff6b35]
                      to-[#f7b801]
                      mx-auto
                      mb-6
                    "
                  />

                  <p className="text-[#f7b801] uppercase tracking-[0.25em] text-sm">
                    Featured Project
                  </p>

                  <h3 className="text-white text-2xl font-semibold mt-4">
                    Website Preview
                  </h3>

                  <p className="text-zinc-500 mt-2">
                    Add Screenshot Later
                  </p>

                </div>

              </div>

            </div>

            {/* Floating Card */}
            <div
              className="
                absolute
                -bottom-8
                left-1/2
                -translate-x-1/2
                w-[85%]
                rounded-3xl
                border
                border-white/10
                bg-white/[0.05]
                backdrop-blur-xl
                px-6
                py-5
              "
            >
              <p className="text-[#f7b801] uppercase tracking-[0.2em] text-sm">
                Latest Project
              </p>

              <h4 className="text-white text-xl font-semibold mt-2">
                Modern Agency Website
              </h4>

              <p className="text-zinc-500 text-sm mt-2">
                Built with Next.js, Tailwind CSS, and Framer Motion.
              </p>
            </div>

          </div>

        </div>
      </div>
    </section>
  )
}