'use client'

import Image from 'next/image'

const technologies = [
  {
    name: 'Next.js',
    description: 'Modern React Framework',
    icon: '/nextjs.png',
  },
  {
    name: 'React',
    description: 'Interactive User Interfaces',
    icon: '/react.png',
  },
  {
    name: 'TypeScript',
    description: 'Type-Safe Development',
    icon: '/typescript.png',
  },
  {
    name: 'Tailwind CSS',
    description: 'Utility-First Styling',
    icon: '/tailwind.png',
  },
  {
    name: 'Framer Motion',
    description: 'Smooth Animations',
    icon: '/framer.png',
  },
  {
    name: 'Node.js',
    description: 'Backend Development',
    icon: '/nodejs.png',
  },
]

export default function TechStack() {
  return (
    <section className="py-32 px-6 bg-[#151515] overflow-hidden">
      <div className="max-w-7xl mx-auto">

        {/* Heading */}
        <div className="text-center mb-20">
          <p className="text-[#f7b801] uppercase tracking-[0.3em] text-sm mb-4">
            Technology Stack
          </p>

          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Built With Modern Technologies
          </h2>

          <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
            We use industry-leading tools and frameworks
            to build fast, scalable, and future-ready websites.
          </p>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-8">

          {technologies.map((tech) => (
            <div
              key={tech.name}
              className="
                group
                relative
                p-8
                rounded-3xl
                border
                border-white/10
                bg-white/[0.03]
                backdrop-blur-sm
                hover:border-[#ff6b35]/40
                hover:-translate-y-2
                hover:shadow-[0_0_50px_rgba(255,107,53,0.15)]
                transition-all
                duration-300
              "
            >

              {/* Glow */}
              <div
                className="
                  absolute
                  inset-0
                  rounded-3xl
                  bg-gradient-to-br
                  from-[#ff6b35]/5
                  to-[#f7b801]/5
                  opacity-0
                  group-hover:opacity-100
                  transition-opacity
                  duration-500
                "
              />

              {/* Icon */}
              <div
                className="
                  relative
                  z-10
                  w-20
                  h-20
                  rounded-3xl
                  bg-gradient-to-br
                  from-[#ff6b35]
                  to-[#f7b801]
                  flex
                  items-center
                  justify-center
                  mb-6
                "
              >
                <Image
                  src={tech.icon}
                  alt={tech.name}
                  width={52}
                  height={52}
                  className="
                    object-contain
                    group-hover:scale-110
                    transition-transform
                    duration-300
                  "
                />
              </div>

              <h3 className="relative z-10 text-2xl font-semibold text-white mb-3">
                {tech.name}
              </h3>

              <p className="relative z-10 text-zinc-400">
                {tech.description}
              </p>

            </div>
          ))}

        </div>

        {/* Bottom Stats */}
        <div className="grid md:grid-cols-3 gap-8 mt-24">

          <div className="text-center">
            <h3 className="text-5xl font-bold text-[#ff6b35] mb-3">
              95+
            </h3>

            <p className="text-zinc-500">
              Performance Score
            </p>
          </div>

          <div className="text-center">
            <h3 className="text-5xl font-bold text-[#ff6b35] mb-3">
              100%
            </h3>

            <p className="text-zinc-500">
              Mobile Responsive
            </p>
          </div>

          <div className="text-center">
            <h3 className="text-5xl font-bold text-[#ff6b35] mb-3">
              SEO
            </h3>

            <p className="text-zinc-500">
              Optimized Structure
            </p>
          </div>

        </div>

      </div>
    </section>
  )
}