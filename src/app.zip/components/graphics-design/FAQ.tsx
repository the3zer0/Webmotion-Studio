'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const faqs = [
  {
    question: 'What design services do you offer?',
    answer:
      'We provide brand identity design, social media creatives, advertising graphics, posters, presentation design, and marketing assets.',
  },
  {
    question: 'How long does a project take?',
    answer:
      'Most projects are completed within 3-10 business days depending on complexity, revisions, and project scope.',
  },
  {
    question: 'Do you provide source files?',
    answer:
      'Yes. Final source files can be delivered upon request depending on the project agreement.',
  },
  {
    question: 'How many revisions are included?',
    answer:
      'Most projects include multiple revision rounds to ensure the final design aligns with your goals.',
  },
  {
    question: 'Can you work with existing brand guidelines?',
    answer:
      'Absolutely. We can design within your existing brand system or help create a completely new one.',
  },
]

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <section className="py-32 px-6 bg-[#151515]">
      <div className="max-w-4xl mx-auto">
        {/* Heading */}
        <div className="text-center mb-20">
          <p className="text-[#f7b801] uppercase tracking-[0.3em] text-sm mb-4">
            FAQ
          </p>

          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Frequently Asked Questions
          </h2>

          <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
            Everything you need to know before starting your design project.
          </p>
        </div>

        {/* FAQ Items */}
        <div className="space-y-5">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index

            return (
              <div
                key={faq.question}
                className="
                  rounded-3xl
                  border
                  border-white/10
                  bg-white/[0.03]
                  overflow-hidden
                "
              >
                <button
                  onClick={() =>
                    setOpenIndex(isOpen ? null : index)
                  }
                  className="
                    w-full
                    flex
                    items-center
                    justify-between
                    p-8
                    text-left
                  "
                >
                  <h3 className="text-white text-xl font-semibold">
                    {faq.question}
                  </h3>

                  <ChevronDown
                    className={`
                      text-[#ff6b35]
                      transition-transform
                      duration-300
                      ${isOpen ? 'rotate-180' : ''}
                    `}
                    size={24}
                  />
                </button>

                <div
                  className={`
                    grid
                    transition-all
                    duration-300
                    ${
                      isOpen
                        ? 'grid-rows-[1fr]'
                        : 'grid-rows-[0fr]'
                    }
                  `}
                >
                  <div className="overflow-hidden">
                    <p className="px-8 pb-8 text-zinc-400 leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}