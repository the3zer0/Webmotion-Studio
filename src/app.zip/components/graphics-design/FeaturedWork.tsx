'use client'

const projects = [
  {
    title: 'Brand Identity',
    category: 'Branding',
  },
  {
    title: 'Social Media Campaign',
    category: 'Social Design',
  },
  {
    title: 'Advertising Creative',
    category: 'Marketing',
  },
  {
    title: 'Instagram Carousel',
    category: 'Content Design',
  },
  {
    title: 'Event Poster',
    category: 'Print Design',
  },
  {
    title: 'Product Promotion',
    category: 'Advertising',
  },
]

export default function FeaturedWork() {
  return (
    <section
      id="portfolio"
      className="py-32 px-6 bg-[#151515]"
    >
      <div className="max-w-7xl mx-auto">

        {/* Heading */}
        <div className="text-center mb-20">
          <p className="text-[#f7b801] uppercase tracking-[0.3em] text-sm mb-4">
            Portfolio
          </p>

          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Featured Work
          </h2>

          <p className="text-zinc-400 max-w-2xl mx-auto text-lg">
            A curated collection of branding, advertising,
            and social media design projects crafted to help
            businesses stand out.
          </p>
        </div>

        {/* Masonry Layout */}
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-8">

          {projects.map((project, index) => (
            <div
              key={project.title}
              className="
                group
                overflow-hidden
                rounded-3xl
                border
                border-white/10
                bg-white/[0.03]
                hover:border-[#ff6b35]/40
                transition-all
                duration-300
              "
            >

              {/* Placeholder Image */}
              <div
                className={`
                  relative
                  overflow-hidden
                  bg-gradient-to-br
                  from-white/[0.03]
                  to-white/[0.01]
                  flex
                  items-center
                  justify-center
                  ${
                    index % 3 === 0
                      ? 'h-[420px]'
                      : index % 2 === 0
                      ? 'h-[320px]'
                      : 'h-[260px]'
                  }
                `}
              >
                <div className="text-center">

                  <div
                    className="
                      w-16
                      h-16
                      rounded-2xl
                      bg-gradient-to-br
                      from-[#ff6b35]
                      to-[#f7b801]
                      mx-auto
                      mb-4
                    "
                  />

                  <p className="text-zinc-500 text-sm uppercase tracking-[0.2em]">
                    Add Design Here
                  </p>

                </div>

                {/* Hover Overlay */}
                <div
                  className="
                    absolute
                    inset-0
                    bg-black/60
                    opacity-0
                    group-hover:opacity-100
                    transition-all
                    duration-300
                    flex
                    items-center
                    justify-center
                  "
                >
                  <span className="text-white font-semibold">
                    View Project
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">

                <p className="text-[#f7b801] text-sm uppercase tracking-[0.2em] mb-2">
                  {project.category}
                </p>

                <h3 className="text-2xl font-semibold text-white">
                  {project.title}
                </h3>

              </div>

            </div>
          ))}

        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-20">
          <a
            href="#contact"
            className="
              inline-flex
              items-center
              px-8
              py-4
              rounded-full
              bg-gradient-to-r
              from-[#ff6b35]
              to-[#f7b801]
              text-black
              font-semibold
              hover:scale-105
              transition
            "
          >
            Start Your Project
          </a>
        </div>

      </div>
    </section>
  )
}