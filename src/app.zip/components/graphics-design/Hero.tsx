'use client'

import Link from 'next/link'

const stats = [
  {
    value: '120+',
    label: 'Design Projects',
  },
  {
    value: '35+',
    label: 'Brands Served',
  },
  {
    value: '4M+',
    label: 'Impressions Generated',
  },
  {
    value: '98%',
    label: 'Client Satisfaction',
  },
]

export default function Hero() {
  return (
    <section className="relative min-h-screen overflow-hidden bg-[#111111]">
      {/* Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[700px] bg-[#ff6b35]/10 blur-[180px]" />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8 pt-40 pb-24">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          {/* LEFT */}
          <div>
            <p className="text-[#f7b801] uppercase tracking-[0.35em] text-sm mb-6">
              GRAPHIC DESIGN • BRANDING • CREATIVE
            </p>

            <h1 className="text-[4rem] md:text-[6rem] leading-[0.9] font-bold text-white">
              WE DESIGN
              <br />
              <span className="bg-gradient-to-r from-[#ff6b35] to-[#f7b801] bg-clip-text text-transparent">
                VISUALS
              </span>
              <br />
              PEOPLE
              <br />
              REMEMBER.
            </h1>

            <p className="mt-8 text-zinc-400 text-lg max-w-xl leading-relaxed">
              We create premium brand identities, social media creatives,
              advertising campaigns, and visual systems designed to elevate
              brands and leave lasting impressions.
            </p>

            <div className="flex flex-wrap gap-4 mt-10">
              <a
                href="#featured-work"
                className="
                  px-8 py-4
                  rounded-full
                  bg-gradient-to-r
                  from-[#ff6b35]
                  to-[#f7b801]
                  text-black
                  font-semibold
                  hover:scale-105
                  transition
                "
              >
                View Work
              </a>

              <Link
                href="/contact"
                className="
                  px-8 py-4
                  rounded-full
                  border
                  border-white/15
                  text-white
                  hover:border-[#ff6b35]
                  transition
                "
              >
                Start Project
              </Link>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16">
              {stats.map((stat) => (
                <div key={stat.label}>
                  <h3 className="text-4xl font-bold text-[#ff6b35]">
                    {stat.value}
                  </h3>

                  <p className="text-zinc-500 mt-2 text-sm">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-5">
              {/* Placeholder 1 */}
              <div
                className="
                  h-[320px]
                  rounded-3xl
                  border
                  border-white/10
                  bg-gradient-to-br
                  from-white/[0.04]
                  to-white/[0.01]
                  backdrop-blur-xl
                  flex
                  items-center
                  justify-center
                "
              >
                <div className="text-center">
                  <p className="text-[#f7b801] text-sm tracking-[0.2em] uppercase mb-3">
                    Portfolio
                  </p>

                  <h3 className="text-white text-xl font-semibold">
                    Poster Design
                  </h3>

                  <p className="text-zinc-500 text-sm mt-2">
                    Add Image Later
                  </p>
                </div>
              </div>

              {/* Placeholder 2 */}
              <div
                className="
                  h-[220px]
                  rounded-3xl
                  border
                  border-white/10
                  bg-gradient-to-br
                  from-white/[0.04]
                  to-white/[0.01]
                  backdrop-blur-xl
                  flex
                  items-center
                  justify-center
                "
              >
                <div className="text-center">
                  <h3 className="text-white text-lg font-semibold">
                    Social Media
                  </h3>

                  <p className="text-zinc-500 text-sm mt-2">
                    Add Image Later
                  </p>
                </div>
              </div>

              {/* Placeholder 3 */}
              <div
                className="
                  h-[220px]
                  rounded-3xl
                  border
                  border-white/10
                  bg-gradient-to-br
                  from-white/[0.04]
                  to-white/[0.01]
                  backdrop-blur-xl
                  flex
                  items-center
                  justify-center
                "
              >
                <div className="text-center">
                  <h3 className="text-white text-lg font-semibold">
                    Branding
                  </h3>

                  <p className="text-zinc-500 text-sm mt-2">
                    Add Image Later
                  </p>
                </div>
              </div>

              {/* Placeholder 4 */}
              <div
                className="
                  h-[320px]
                  rounded-3xl
                  border
                  border-white/10
                  bg-gradient-to-br
                  from-white/[0.04]
                  to-white/[0.01]
                  backdrop-blur-xl
                  flex
                  items-center
                  justify-center
                "
              >
                <div className="text-center">
                  <h3 className="text-white text-xl font-semibold">
                    Ad Creative
                  </h3>

                  <p className="text-zinc-500 text-sm mt-2">
                    Add Image Later
                  </p>
                </div>
              </div>
            </div>

            {/* Floating Card */}
            <div
              className="
                absolute
                -bottom-8
                left-1/2
                -translate-x-1/2
                backdrop-blur-xl
                bg-white/5
                border
                border-white/10
                rounded-3xl
                px-6
                py-5
                w-[85%]
              "
            >
              <p className="text-[#f7b801] text-sm tracking-[0.2em] uppercase">
                Creative Partner
              </p>

              <h4 className="text-white text-xl font-semibold mt-2">
                Building Brands Through Design
              </h4>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}