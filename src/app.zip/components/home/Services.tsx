'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { Palette, Video, Code, Zap } from 'lucide-react'

const services = [
  {
    icon: Palette,
    number: '01',
    title: 'Graphics Design',
    description: 'Stunning visual designs that capture your brand essence and engage your audience.',
    href: '/graphics-design',
  },
  {
    icon: Video,
    number: '02',
    title: 'Video Editing',
    description: 'Professional video production and editing that tells your story compellingly.',
    href: '/video-editing',
  },
  {
    icon: Code,
    number: '03',
    title: 'Frontend Development',
    description: 'Modern, responsive web interfaces built with cutting-edge technologies.',
    href: '/web-dev',
  },
  {
    icon: Zap,
    number: '04',
    title: 'Brand Strategy',
    description: 'Strategic consulting to elevate your brand presence in the digital world.',
  },
]

export default function Services() {
  return (
    <section id="services" className="relative py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-dark via-dark to-secondary/5 overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl -z-10 opacity-50" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/10 rounded-full blur-3xl -z-10 opacity-50" />

      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              Our Services
            </span>
          </h2>
          <p className="text-xl text-light/70 max-w-2xl mx-auto">
            We deliver exceptional services that combine creativity with technical excellence
          </p>
        </motion.div>

        {/* Services grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="group relative p-8 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20 hover:border-primary/50 transition-all duration-300 overflow-hidden"
              >
                {/* Animated background */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10" />

                {/* Icon */}
                <motion.div
                  whileHover={{ rotate: 12, scale: 1.1 }}
                  className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6"
                >
                  <Icon size={32} className="text-dark" />
                </motion.div>

                {/* Service number */}
                <span className="text-6xl font-bold text-primary/20 absolute top-4 right-4">
                  {service.number}
                </span>

                {/* Content */}
                <h3 className="text-xl font-bold mb-3 text-light">{service.title}</h3>
                <p className="text-light/60 group-hover:text-light/80 transition-colors duration-300">
                  {service.description}
                </p>

                {'href' in service && (
                  <Link
                    href={service.href}
                    className="inline-flex mt-6 text-primary font-semibold hover:text-accent transition-colors duration-300"
                  >
                    Explore service →
                  </Link>
                )}

                {/* Hover indicator */}
                <motion.div
                  initial={{ width: 0 }}
                  whileHover={{ width: '100%' }}
                  transition={{ duration: 0.3 }}
                  className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-primary to-accent"
                />
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
