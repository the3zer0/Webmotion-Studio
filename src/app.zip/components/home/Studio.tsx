'use client'

import { motion } from 'framer-motion'
import { Users, Globe, Award, Lightbulb } from 'lucide-react'

const studioValues = [
  {
    icon: Users,
    title: 'Collaborative',
    description: 'We work closely with our clients to understand their vision and bring it to life.',
  },
  {
    icon: Lightbulb,
    title: 'Creative',
    description: 'Innovation and creativity drive everything we do in every project.',
  },
  {
    icon: Award,
    title: 'Excellence',
    description: 'We never compromise on quality or attention to detail.',
  },
  {
    icon: Globe,
    title: 'Global',
    description: 'Serving clients internationally with diverse expertise and perspectives.',
  },
]

export default function Studio() {
  return (
    <section id="studio" className="relative py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-dark to-secondary/10 overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-secondary/10 rounded-full blur-3xl -z-10 opacity-50" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl -z-10 opacity-50" />

      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              About Our Studio
            </span>
          </h2>
          <p className="text-xl text-light/70 max-w-3xl">
            At Webmotion Studio, we're passionate about creating digital experiences that matter. With a team of talented designers, video editors, and developers, we transform ideas into reality.
          </p>
        </motion.div>

        {/* Two column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
          {/* Left side - Stats */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div>
              <h3 className="text-5xl font-bold text-primary mb-2">150+</h3>
              <p className="text-light/70 text-lg">Projects Completed</p>
            </div>
            <div>
              <h3 className="text-5xl font-bold text-accent mb-2">50+</h3>
              <p className="text-light/70 text-lg">Happy Clients Worldwide</p>
            </div>
            <div>
              <h3 className="text-5xl font-bold text-primary mb-2">8+</h3>
              <p className="text-light/70 text-lg">Years of Experience</p>
            </div>
            <div>
              <h3 className="text-5xl font-bold text-accent mb-2">20+</h3>
              <p className="text-light/70 text-lg">Team Members & Specialists</p>
            </div>
          </motion.div>

          {/* Right side - Image placeholder */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative h-96 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 border border-primary/30 overflow-hidden">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                className="absolute inset-0 bg-gradient-to-br from-primary/30 via-transparent to-accent/30"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">🎨</div>
                  <h4 className="text-2xl font-bold text-light">Webmotion Studio</h4>
                  <p className="text-light/60 mt-2">Creating Digital Magic</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Values grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {studioValues.map((value, index) => {
            const Icon = value.icon
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                className="p-6 rounded-xl bg-primary/5 border border-primary/20 hover:border-primary/50 transition-all duration-300 group"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Icon size={24} className="text-dark" />
                </div>
                <h3 className="text-lg font-bold text-light mb-2">{value.title}</h3>
                <p className="text-light/60 text-sm">{value.description}</p>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
