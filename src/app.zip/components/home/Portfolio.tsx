'use client'

import { motion } from 'framer-motion'
import { ExternalLink, ArrowRight } from 'lucide-react'

const portfolioProjects = [
  {
    id: 1,
    title: 'Brand Identity System',
    category: 'Graphics Design',
    description: 'Complete brand identity redesign including logo, guidelines, and assets',
    tags: ['Design', 'Branding', 'UI/UX'],
    color: 'from-primary/40 to-accent/40',
  },
  {
    id: 2,
    title: 'Product Launch Video',
    category: 'Video Editing',
    description: 'High-impact product launch video with motion graphics',
    tags: ['Video', 'Motion', 'Post-Production'],
    color: 'from-accent/40 to-secondary/40',
  },
  {
    id: 3,
    title: 'E-Commerce Platform',
    category: 'Frontend Development',
    description: 'Modern responsive e-commerce website with advanced features',
    tags: ['Web Dev', 'React', 'Performance'],
    color: 'from-secondary/40 to-primary/40',
  },
  {
    id: 4,
    title: 'Social Media Campaign',
    category: 'Graphics Design & Video',
    description: 'Integrated multi-platform social media campaign assets',
    tags: ['Design', 'Video', 'Social Media'],
    color: 'from-primary/40 to-secondary/40',
  },
  {
    id: 5,
    title: 'Interactive Dashboard',
    category: 'Frontend Development',
    description: 'Data visualization dashboard with real-time analytics',
    tags: ['Web Dev', 'Dashboard', 'Data'],
    color: 'from-accent/40 to-primary/40',
  },
  {
    id: 6,
    title: 'Brand Documentary',
    category: 'Video Editing',
    description: 'Company story told through cinematic documentary footage',
    tags: ['Documentary', 'Video', 'Storytelling'],
    color: 'from-secondary/40 to-accent/40',
  },
]

export default function Portfolio() {
  return (
    <section id="portfolio" className="relative py-24 px-4 sm:px-6 lg:px-8 bg-dark overflow-hidden">
      {/* Background elements */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
        className="absolute top-40 left-10 w-80 h-80 bg-primary/5 rounded-full blur-3xl -z-10"
      />

      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              Featured Work
            </span>
          </h2>
          <p className="text-xl text-light/70 max-w-2xl mx-auto">
            Showcase of our best projects across design, video, and web development
          </p>
        </motion.div>

        {/* Portfolio grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {portfolioProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              whileHover={{ y: -15 }}
              className="group cursor-pointer"
            >
              <div className={`relative h-64 rounded-2xl bg-gradient-to-br ${project.color} border border-primary/20 overflow-hidden mb-6`}>
                {/* Image placeholder */}
                <div className="w-full h-full flex items-center justify-center relative overflow-hidden">
                  <motion.div
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 3, repeat: Infinity }}
                    className="absolute inset-0 bg-gradient-to-br from-transparent via-white/5 to-transparent"
                  />
                  <div className="text-center relative z-10">
                    <h3 className="text-2xl font-bold text-light mb-2">{project.title.split(' ')[0]}</h3>
                    <p className="text-light/60 text-sm">{project.category}</p>
                  </div>
                </div>

                {/* Hover overlay */}
                <motion.div
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  className="absolute inset-0 bg-dark/80 backdrop-blur-sm flex items-center justify-center"
                >
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    className="w-14 h-14 rounded-full bg-gradient-to-r from-primary to-accent flex items-center justify-center text-dark"
                  >
                    <ExternalLink size={24} />
                  </motion.button>
                </motion.div>
              </div>

              {/* Project info */}
              <h3 className="text-xl font-bold text-light mb-2 group-hover:text-primary transition-colors">
                {project.title}
              </h3>
              <p className="text-light/60 mb-4 text-sm">{project.description}</p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2">
                {project.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-xs px-3 py-1 bg-primary/20 text-primary rounded-full"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* View all button */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center"
        >
          <button className="px-8 py-4 border-2 border-primary text-primary rounded-full font-bold hover:bg-primary/10 transition-all duration-300 flex items-center gap-2 mx-auto">
            View All Projects
            <ArrowRight size={20} />
          </button>
        </motion.div>
      </div>
    </section>
  )
}
