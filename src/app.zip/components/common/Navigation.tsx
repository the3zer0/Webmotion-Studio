'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Menu, X } from 'lucide-react'
import { motion } from 'framer-motion'

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] =
    useState(false)

  const [isScrolled, setIsScrolled] =
    useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener(
      'scroll',
      handleScroll
    )

    return () => {
      window.removeEventListener(
        'scroll',
        handleScroll
      )
    }
  }, [])

  const navItems = [
    {
      label: 'Home',
      href: '/',
    },
    {
      label: 'Graphics Design',
      href: '/graphics-design',
    },
    {
      label: 'Video Editing',
      href: '/video-editing',
    },
    {
      label: 'Web Development',
      href: '/web-dev',
    },
    {
      label: 'Pricing',
      href: '/pricing',
    },
  ]

  const scrollToContact = () => {
    const element =
      document.getElementById('contact')

    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
      })
    }

    setIsMobileMenuOpen(false)
  }

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#111111]/95 backdrop-blur-md border-b border-white/10'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-4 flex justify-between items-center">

        {/* Logo */}
        <Link href="/">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-2xl font-bold cursor-pointer"
          >
            <span className="text-[#ff6b35]">
              WM
            </span>{' '}
            <span className="text-[#f7b801]">
              Studio
            </span>
          </motion.div>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">

          {navItems.map(
            (item, index) => (
              <motion.div
                key={item.label}
                initial={{
                  opacity: 0,
                  y: -10,
                }}
                animate={{
                  opacity: 1,
                  y: 0,
                }}
                transition={{
                  delay: index * 0.08,
                }}
              >
                <Link
                  href={item.href}
                  className="
                    text-white
                    hover:text-[#ff6b35]
                    transition-colors
                    duration-300
                    font-medium
                  "
                >
                  {item.label}
                </Link>
              </motion.div>
            )
          )}

          <button
            onClick={scrollToContact}
            className="
              text-white
              hover:text-[#ff6b35]
              transition-colors
              duration-300
              font-medium
            "
          >
            Contact
          </button>

          <button
            onClick={scrollToContact}
            className="
              px-6
              py-3
              rounded-full
              bg-[#ff6b35]
              text-black
              font-semibold
              hover:scale-105
              transition-all
              duration-300
            "
          >
            Start Project
          </button>

        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() =>
            setIsMobileMenuOpen(
              !isMobileMenuOpen
            )
          }
          className="md:hidden text-[#ff6b35]"
        >
          {isMobileMenuOpen ? (
            <X size={26} />
          ) : (
            <Menu size={26} />
          )}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{
            opacity: 0,
            y: -15,
          }}
          animate={{
            opacity: 1,
            y: 0,
          }}
          className="
            md:hidden
            bg-[#111111]/98
            backdrop-blur-md
            border-t
            border-white/10
          "
        >
          <div className="px-6 py-5 flex flex-col gap-3">

            {navItems.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                onClick={() =>
                  setIsMobileMenuOpen(false)
                }
                className="
                  text-white
                  hover:text-[#ff6b35]
                  py-2
                  transition-colors
                "
              >
                {item.label}
              </Link>
            ))}

            <button
              onClick={scrollToContact}
              className="
                text-left
                text-white
                hover:text-[#ff6b35]
                py-2
                transition-colors
              "
            >
              Contact
            </button>

            <button
              onClick={scrollToContact}
              className="
                mt-3
                px-5
                py-3
                rounded-xl
                bg-[#ff6b35]
                text-black
                font-semibold
              "
            >
              Start Project
            </button>

          </div>
        </motion.div>
      )}
    </motion.nav>
  )
}