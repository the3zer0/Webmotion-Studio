'use client'

import Link from 'next/link'
import Image from 'next/image'
import { motion } from 'framer-motion'

export default function Footer() {
  const currentYear = new Date().getFullYear()

  const socialLinks = [
    {
      name: 'Instagram',
      icon: '/instagram.png',
      href: '#',
    },
    {
      name: 'Facebook',
      icon: '/facebook.png',
      href: '#',
    },
    {
      name: 'LinkedIn',
      icon: '/linkedin.png',
      href: '#',
    },
    {
      name: 'YouTube',
      icon: '/youtube.png',
      href: '#',
    },
  ]

  return (
    <footer className="bg-[#111111] border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">

        {/* Main Footer */}
        <div className="grid lg:grid-cols-[1.6fr_1fr_1fr_1fr] gap-16">

          {/* Brand + Contact */}
          <div>
            <h2 className="text-4xl font-bold mb-8">
              <span className="text-[#ff6b35]">WM</span>
              <span className="text-[#f7b801]">Studio</span>
            </h2>

            <h3 className="text-white font-semibold text-xl mb-6">
              Contact Us
            </h3>

            <div className="space-y-5">

              <div>
                <p className="text-[#f7b801] font-medium mb-1">
                  WhatsApp:
                </p>

                <a
                  href="https://wa.me/8801XXXXXXXXXX"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  +8801XXXXXXXXXX
                </a>
              </div>

              <div>
                <p className="text-[#f7b801] font-medium mb-1">
                  Email:
                </p>

                <a
                  href="mailto:hello@webmotionstudio.com"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  hello@webmotionstudio.com
                </a>
              </div>

              <div>
                <p className="text-[#f7b801] font-medium mb-1">
                  Location:
                </p>

                <p className="text-zinc-400">
                  Dhaka, Bangladesh
                  <br />
                  Available Worldwide
                </p>
              </div>

            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white font-semibold text-xl mb-6">
              Services
            </h3>

            <ul className="space-y-4">
              <li>
                <Link
                  href="/graphics-design"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  Graphics Design
                </Link>
              </li>

              <li>
                <Link
                  href="/video-editing"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  Video Editing
                </Link>
              </li>

              <li>
                <Link
                  href="/web-dev"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  Web Development
                </Link>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-white font-semibold text-xl mb-6">
              Company
            </h3>

            <ul className="space-y-4">
              <li>
                <a
                  href="#studio"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  About Us
                </a>
              </li>

              <li>
                <Link
                  href="/blog"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  Blog
                </Link>
              </li>

              <li>
                <Link
                  href="/careers"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  Careers
                </Link>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold text-xl mb-6">
              Quick Links
            </h3>

            <ul className="space-y-4">
              <li>
                <Link
                  href="/privacy"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  Privacy Policy
                </Link>
              </li>

              <li>
                <Link
                  href="/terms"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  Terms & Conditions
                </Link>
              </li>

              <li>
                <Link
                  href="/support"
                  className="text-zinc-400 hover:text-[#ff6b35] transition"
                >
                  Support
                </Link>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom */}
        <div className="mt-16 flex flex-col items-end gap-5">

          {/* Social Links */}
          <div className="flex gap-4">
            {socialLinks.map((social) => (
              <motion.a
                key={social.name}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{
                  scale: 1.08,
                  y: -3,
                }}
                whileTap={{
                  scale: 0.95,
                }}
                className="
                  w-11
                  h-11
                  rounded-xl
                  border
                  border-[#ff6b35]/20
                  bg-[#ff6b35]/10
                  flex
                  items-center
                  justify-center
                  hover:border-[#ff6b35]/50
                  hover:bg-[#ff6b35]/20
                  transition-all
                  duration-300
                "
              >
                <Image
                  src={social.icon}
                  alt={social.name}
                  width={20}
                  height={20}
                  className="object-contain"
                />
              </motion.a>
            ))}
          </div>

          {/* Copyright */}
          <p className="text-zinc-500 text-sm">
            © {currentYear} Webmotion Studio. All rights reserved.
          </p>

        </div>

      </div>
    </footer>
  )
}