'use client'

import { motion } from 'framer-motion'
import { useState } from 'react'
import Image from 'next/image'

export default function FloatingWhatsApp() {
  const [isHovered, setIsHovered] = useState(false)

  const whatsappLink = 'https://wa.me/8801XXXXXXXXX' // Replace with your number

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.5, type: 'spring' }}
      className="fixed bottom-8 right-8 z-40"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Animated background pulse */}
      <motion.div
        animate={{ scale: [1, 1.15, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute inset-0 bg-green-500/20 rounded-full"
      />

      {/* Main button */}
      <motion.a
        href={whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        className="
          relative
          w-16
          h-16
          rounded-full
          bg-[#25D366]
          flex
          items-center
          justify-center
          shadow-lg
          hover:shadow-2xl
          hover:shadow-green-500/40
          transition-all
          duration-300
          cursor-pointer
        "
      >
        <Image
          src="/whatsapp.svg"
          alt="WhatsApp"
          width={32}
          height={32}
          className="object-contain"
        />

        {/* Tooltip */}
        <motion.div
          initial={{ opacity: 0, x: 10 }}
          animate={{
            opacity: isHovered ? 1 : 0,
            x: isHovered ? -120 : 10,
          }}
          transition={{ duration: 0.2 }}
          className="
            absolute
            right-20
            px-4
            py-2
            bg-[#111111]
            rounded-lg
            text-green-400
            text-sm
            font-medium
            whitespace-nowrap
            pointer-events-none
          "
        >
          Chat on WhatsApp

          <div
            className="
              absolute
              left-0
              top-1/2
              -translate-y-1/2
              w-2
              h-2
              bg-[#111111]
              rotate-45
              -ml-1
            "
          />
        </motion.div>
      </motion.a>

      {/* Floating dots */}
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          animate={{
            y: [0, -20, 0],
            opacity: [1, 0.5, 1],
          }}
          transition={{
            duration: 2,
            delay: i * 0.2,
            repeat: Infinity,
          }}
          className="absolute w-2 h-2 bg-green-500 rounded-full"
          style={{
            bottom: '80px',
            right: `${20 + i * 8}px`,
          }}
        />
      ))}
    </motion.div>
  )
}