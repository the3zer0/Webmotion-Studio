'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const faqs = [
  {
    question: 'What type of videos do you edit?',
    answer:
      'We create high-quality edits tailored to your brand and audience — including short-form content, cinematic reels, YouTube videos, ads, podcasts, brand promos, social media content, and creative storytelling edits.',
  },
  {
    question: 'How can I send my footage?',
    answer:
      'You can share files through Google Drive, Dropbox, WeTransfer, or any cloud storage platform. Once we begin, we’ll guide you through the process smoothly.',
  },
  {
    question: 'Do you offer revisions?',
    answer:
      'Yes. Revisions are included to ensure the final video matches your vision and brand style. Revision limits depend on the selected package.',
  },
  {
    question: 'Can you match my brand style?',
    answer:
      'Absolutely. We carefully match your colors, fonts, captions, transitions, pacing, and editing style to keep your content professional, recognizable, and consistent across all platforms.',
  },
  {
    question: 'Do you work on monthly retainers or one-time projects?',
    answer:
      'We offer both. Whether you need a single project edited or ongoing monthly content support, we have flexible packages for creators, businesses, agencies, and personal brands.',
  },
  {
    question: 'How long does delivery take?',
    answer:
      'Turnaround time depends on the project size and complexity, but we always aim for fast, high-quality delivery without compromising the final result.',
  },
  {
    question: 'Can you help with content ideas and strategy too?',
    answer:
      'Yes. Along with editing, we can help improve hooks, pacing, captions, storytelling, and content structure to make your videos more engaging and platform-friendly.',
  },
]

export default function FAQ() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null)

  const toggleFAQ = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index)
  }

  return (
    <section
      id="faq"
      className="relative py-32 px-6 bg-[#1a1a1a] overflow-hidden"
    >
      {/* Glow */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#ff6b35]/10 blur-[180px]" />

      <div className="max-w-5xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-20"
        >
          <p className="text-[#f7b801] uppercase tracking-[0.3em] text-sm mb-4">
            FAQ
          </p>

          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Frequently Asked
            <span className="text-[#ff6b35]"> Questions</span>
          </h2>

          <p className="text-zinc-400 max-w-2xl mx-auto text-lg">
            Got questions? Learn more about the workflow, pricing,
            revisions, delivery times, and how we help creators
            and brands produce content that performs.
          </p>
        </motion.div>

        {/* FAQ Items */}
        <div className="space-y-5">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.5,
                delay: index * 0.05,
              }}
              whileHover={{ y: -3 }}
              className="
                rounded-3xl
                border
                border-white/10
                bg-white/[0.03]
                backdrop-blur-sm
                overflow-hidden
                hover:border-[#ff6b35]/40
                transition-all
                duration-300
              "
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="
                  w-full
                  flex
                  items-center
                  justify-between
                  text-left
                  p-7
                "
              >
                <div className="flex items-center gap-5">
                  <span className="text-[#f7b801] text-sm font-bold">
                    {String(index + 1).padStart(2, '0')}
                  </span>

                  <span className="text-white font-medium text-lg">
                    {faq.question}
                  </span>
                </div>

                <motion.span
                  animate={{
                    rotate:
                      activeIndex === index ? 45 : 0,
                  }}
                  transition={{ duration: 0.2 }}
                  className="
                    text-[#ff6b35]
                    text-3xl
                    leading-none
                    font-light
                  "
                >
                  +
                </motion.span>
              </button>

              <AnimatePresence>
                {activeIndex === index && (
                  <motion.div
                    initial={{
                      height: 0,
                      opacity: 0,
                    }}
                    animate={{
                      height: 'auto',
                      opacity: 1,
                    }}
                    exit={{
                      height: 0,
                      opacity: 0,
                    }}
                    transition={{
                      duration: 0.3,
                    }}
                    className="overflow-hidden"
                  >
                    <div className="px-7 pb-7 pl-[4.8rem]">
                      <p className="text-zinc-400 leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="
            mt-16
            text-center
            p-10
            rounded-[2rem]
            border
            border-[#ff6b35]/20
            bg-gradient-to-r
            from-[#ff6b35]/10
            to-[#f7b801]/5
          "
        >
          <h3 className="text-3xl font-bold text-white mb-4">
            Have a project in mind?
          </h3>

          <p className="text-zinc-400 mb-8 max-w-xl mx-auto">
            Let's create content people actually watch,
            remember, and share.
          </p>

          <a
            href="#contact"
            className="
              inline-flex
              items-center
              gap-2
              px-8
              py-4
              rounded-full
              bg-[#ff6b35]
              text-black
              font-semibold
              hover:scale-105
              transition-all
              duration-300
            "
          >
            Start Your Project →
          </a>
        </motion.div>
      </div>
    </section>
  )
}