import Link from 'next/link'

export const metadata = {
  title: 'Support — Webmotion Studio',
  description: 'Support and help resources for Webmotion Studio',
}

export default function SupportPage() {
  return (
    <main className="min-h-screen bg-dark text-light pt-24 px-6 pb-16">
      <div className="max-w-4xl mx-auto space-y-10">
        <header className="space-y-4">
          <p className="text-primary font-semibold uppercase tracking-[0.3em] text-sm">Webmotion Studio</p>
          <h1 className="text-4xl sm:text-5xl font-bold">Support</h1>
          <p className="text-light/70 text-lg leading-relaxed">
            Need help with a project, a quote, or your deliverables? Start here. This page gives visitors a clear
            path to contact the studio and understand how support works.
          </p>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <article className="p-6 rounded-2xl bg-white/5 border border-white/10 space-y-3">
            <h2 className="text-2xl font-bold">General Support</h2>
            <p className="text-light/70 leading-relaxed">
              For project questions, file updates, or general help, email us at{' '}
              <a href="mailto:hola@webmotion.studio" className="text-primary hover:underline">
                hola@webmotion.studio
              </a>
              .
            </p>
          </article>

          <article className="p-6 rounded-2xl bg-white/5 border border-white/10 space-y-3">
            <h2 className="text-2xl font-bold">Fast Response</h2>
            <p className="text-light/70 leading-relaxed">
              We usually respond within 24 hours on business days. If your request is urgent, use WhatsApp or the
              contact form on the home page for a quicker reply.
            </p>
          </article>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">What We Can Help With</h2>
          <ul className="space-y-3 text-light/70 list-disc pl-5">
            <li>Project status updates and delivery timelines</li>
            <li>Revisions, file formats, and handoff questions</li>
            <li>Website, design, or video service inquiries</li>
            <li>Billing or invoice follow-up</li>
          </ul>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20">
          <h2 className="text-2xl font-bold">Need Immediate Help?</h2>
          <p className="text-light/70 leading-relaxed">
            Use the floating WhatsApp button on the site to reach us instantly, or return to the home page to send a
            message through the contact form.
          </p>
          <Link href="/" className="inline-flex text-primary font-semibold hover:underline">
            ← Back to home
          </Link>
        </section>
      </div>
    </main>
  )
}
