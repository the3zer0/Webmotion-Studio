import Link from 'next/link'

export const metadata = {
  title: 'Terms & Conditions — Webmotion Studio',
  description: 'Terms and conditions for using Webmotion Studio site and services',
}

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-dark text-light pt-24 px-6 pb-16">
      <div className="max-w-4xl mx-auto space-y-10">
        <header className="space-y-4">
          <p className="text-primary font-semibold uppercase tracking-[0.3em] text-sm">Webmotion Studio</p>
          <h1 className="text-4xl sm:text-5xl font-bold">Terms & Conditions</h1>
          <p className="text-light/70 text-lg leading-relaxed">
            These terms explain how you can use the Webmotion Studio website and the rules that apply when you
            contact us or work with us. This is a practical starter version that you should replace with legal
            review before launch.
          </p>
        </header>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">1. Website Use</h2>
          <p className="text-light/70 leading-relaxed">
            You may browse this site, read our content, and contact us about services. You agree not to misuse the
            website, attempt unauthorized access, or interfere with its performance.
          </p>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">2. Services and Proposals</h2>
          <p className="text-light/70 leading-relaxed">
            Any service scope, timeline, revisions, and fees will be defined in a proposal, quote, or agreement
            shared with you before work starts. If there is any difference between this page and a signed agreement,
            the signed agreement will apply.
          </p>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">3. Intellectual Property</h2>
          <p className="text-light/70 leading-relaxed">
            Unless otherwise agreed in writing, final deliverables become available to you after full payment. We may
            still showcase completed work in our portfolio, unless your agreement says otherwise.
          </p>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">4. Payments and Refunds</h2>
          <p className="text-light/70 leading-relaxed">
            Payment schedules, deposits, and refund terms will be listed in your project agreement. Late payments may
            delay delivery until balances are settled.
          </p>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">5. Changes to These Terms</h2>
          <p className="text-light/70 leading-relaxed">
            We may update these terms from time to time. When we do, the new version will be posted on this page with
            an updated effective date.
          </p>
        </section>

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pt-4">
          <p className="text-light/50 text-sm">Effective date: June 2, 2026</p>
          <Link href="/" className="text-light/60 hover:text-primary transition-colors">← Back to home</Link>
        </div>
      </div>
    </main>
  )
}
