import Hero from '@/components/web-dev/Hero'
import FeaturedWork from '@/components/web-dev/FeaturedWork'
import Services from '@/components/web-dev/Services'
import TechStack from '@/components/web-dev/TechStack'
import Process from '@/components/web-dev/Process'
import Testimonials from '@/components/web-dev/Testimonials'
import FAQ from '@/components/web-dev/FAQ'
import Contact from '@/components/common/Contact'

export default function WebDevPage() {
  return (
    <main className="bg-dark text-light">
      <Hero />
      <FeaturedWork />
      <Services />
      <TechStack />
      <Process />
      <Testimonials />
      <FAQ />
      <Contact
  title="Let's Build Your Next Website."
  description="Whether you need a landing page, business website, portfolio, or custom web application, let's discuss your project."
/>
    </main>
  )
}