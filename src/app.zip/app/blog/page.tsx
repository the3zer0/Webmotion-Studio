import Link from 'next/link'

export const metadata = {
  title: 'Blog — Webmotion Studio',
  description: 'Articles and updates from Webmotion Studio',
}

export default function BlogPage() {
  return (
    <main className="min-h-screen bg-dark text-light pt-24 px-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Blog</h1>
        <p className="text-light/70 mb-8">This is a placeholder blog index. Add posts under a CMS or create static pages here.</p>

        <div className="space-y-6">
          <article className="p-6 rounded-lg bg-primary/5 border border-primary/10">
            <h2 className="text-2xl font-bold">Welcome to the Webmotion Studio Blog</h2>
            <p className="text-light/70 mt-2">We’ll publish case studies, design notes, and industry insights here.</p>
            <Link href="/blog/welcome" className="inline-block mt-4 text-primary font-bold">Read more →</Link>
          </article>
        </div>

        <div className="mt-12">
          <Link href="/" className="text-light/60 hover:text-primary">← Back to home</Link>
        </div>
      </div>
    </main>
  )
}
