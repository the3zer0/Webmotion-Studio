import Hero from '@/components/video-editing/Hero'
import TheStory from '@/components/video-editing/TheStory'
import PortfolioEcosystem from '@/components/video-editing/PortfolioEcosystem'
import Services from '@/components/video-editing/Services'
import Process from '@/components/video-editing/Process'
import Testimonials from '@/components/video-editing/Testimonials'
import FAQ from '@/components/video-editing/FAQ'
import Contact from '@/components/common/Contact'



export default function VideoEditingPage() {
  return (
    <main className="bg-dark text-light">
      <Hero />
      <TheStory />
      <PortfolioEcosystem />
      <Services />
      <Process />
      <Testimonials />
      <FAQ />
      
      <Contact
  title="Let's Build Your Next Website."
  description="Whether you need a landing page, business website, portfolio, or custom web application, let's discuss your project."
/>
      
    </main>
  )
}