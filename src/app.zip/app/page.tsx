'use client'

import { useEffect, useState } from 'react'

import Navigation from '@/components/common/Navigation'
import Footer from '@/components/common/Footer'
import FloatingWhatsApp from '@/components/common/FloatingWhatsApp'

import Hero from '@/components/home/Hero'
import Services from '@/components/home/Services'
import Portfolio from '@/components/home/Portfolio'
import Testimonials from '@/components/home/Testimonials'
import Studio from '@/components/home/Studio'
import Contact from '@/components/common/Contact'

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener('scroll', handleScroll)

    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <div className="min-h-screen bg-dark">
      <Navigation />

      <Hero />
      <Services />
      <Portfolio />
      <Testimonials />
      <Studio />
      <Contact
  title="Let's Build Something Exceptional"
  description="Tell us about your project and we'll get back to you within 24 hours."
/>

      <FloatingWhatsApp />
    </div>
  )
}