import Hero from '@/components/graphics-design/Hero'
import FeaturedWork from '@/components/graphics-design/FeaturedWork'
import Services from '@/components/graphics-design/Services'
import Process from '@/components/graphics-design/Process'
import Testimonials from '@/components/graphics-design/Testimonials'
import FAQ from '@/components/graphics-design/FAQ'
import Contact from '@/components/common/Contact'

export default function GraphicsDesignPage() {
  return (
    <main className="bg-dark text-light">
      <Hero />

      {/* Portfolio */}
      <FeaturedWork />

      {/* Services */}
      <Services />

      {/* Process */}
      <Process />

      {/* Social Proof */}
      <Testimonials />

      {/* FAQ */}
      <FAQ />

      {/* Contact */}
      <Contact
  title="Let's Build Something Remarkable."
  description="Whether you're launching a brand, promoting a product, or improving your visual identity, we're ready to create designs that make an impact."
/>
    </main>
  )
}