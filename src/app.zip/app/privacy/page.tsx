import Link from 'next/link'

export const metadata = {
  title: 'Privacy Policy — Webmotion Studio',
  description: 'Privacy policy and data handling at Webmotion Studio',
}

export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-dark text-light pt-24 px-6 pb-16">
      <div className="max-w-4xl mx-auto space-y-10">
        <header className="space-y-4">
          <p className="text-primary font-semibold uppercase tracking-[0.3em] text-sm">Webmotion Studio</p>
          <h1 className="text-4xl sm:text-5xl font-bold">Privacy Policy</h1>
          <p className="text-light/70 text-lg leading-relaxed">
            This policy explains what information we collect, how we use it, and the choices you have when you visit
            or contact Webmotion Studio. It is a starter version and should be reviewed before publishing.
          </p>
        </header>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">1. Information We Collect</h2>
          <p className="text-light/70 leading-relaxed">
            We may collect the information you choose to send us through contact forms, email, WhatsApp, or project
            inquiries. This can include your name, email address, phone number, company name, and the content of your
            message.
          </p>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">2. How We Use Information</h2>
          <p className="text-light/70 leading-relaxed">
            We use your information to respond to inquiries, prepare quotes, communicate about projects, deliver our
            services, and improve the website experience. We do not sell your personal information.
          </p>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">3. Cookies and Analytics</h2>
          <p className="text-light/70 leading-relaxed">
            If analytics or cookies are enabled in the future, they may be used to understand traffic patterns and
            improve performance. You can manage cookies through your browser settings.
          </p>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">4. Data Sharing</h2>
          <p className="text-light/70 leading-relaxed">
            We may share information with trusted service providers only when needed to operate our business, such as
            hosting, email, or workflow tools. We require them to handle data responsibly.
          </p>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-white/5 border border-white/10">
          <h2 className="text-2xl font-bold">5. Your Choices</h2>
          <p className="text-light/70 leading-relaxed">
            You can ask us to update or delete your contact information by reaching out through the support page or by
            email. If you no longer want to receive messages from us, let us know and we will stop contact where
            possible.
          </p>
        </section>

        <section className="space-y-4 p-6 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20">
          <h2 className="text-2xl font-bold">6. Contact Us</h2>
          <p className="text-light/70 leading-relaxed">
            If you have questions about this policy, contact us at{' '}
            <a href="mailto:hola@webmotion.studio" className="text-primary hover:underline">
              hola@webmotion.studio
            </a>
            .
          </p>
          <p className="text-light/50 text-sm">Effective date: June 2, 2026</p>
        </section>

        <div>
          <Link href="/" className="text-light/60 hover:text-primary transition-colors">← Back to home</Link>
        </div>
      </div>
    </main>
  )
}
